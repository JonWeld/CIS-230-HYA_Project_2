package com.example.expense_trackerexperimental_20;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class ReportActivity extends AppCompatActivity {

    private TextView incomeReportTextView;
    private TextView expenseReportTextView;
    private TextView budgetReportTextView;
    private FrameLayout chartContainerReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        incomeReportTextView = findViewById(R.id.incomeReportTextView);
        expenseReportTextView = findViewById(R.id.expenseReportTextView);
        budgetReportTextView = findViewById(R.id.budgetReportTextView);
        chartContainerReport = findViewById(R.id.chartContainerReport);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        int income = intent.getIntExtra("income", 0);
        int expense = intent.getIntExtra("expense", 0);
        int budget = intent.getIntExtra("budget", 0);

        incomeReportTextView.setText(getString(R.string.income_Str) + income);
        expenseReportTextView.setText(getString(R.string.expense_Str) + expense);
        budgetReportTextView.setText(getString(R.string.budget_Str) + budget);

        drawLineGraph(income, expense, budget);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void drawLineGraph(int income, int expense, int budget) {
        LineGraphView graphView = new LineGraphView(this, income, expense, budget);
        chartContainerReport.addView(graphView);
    }

    private class LineGraphView extends View {

        private final int income;
        private final int expense;
        private final int budget;

        private final Paint linePaint;
        private final Paint pointPaint;
        private final Path path;

        public LineGraphView(Context context, int income, int expense, int budget) {
            super(context);

            this.income = income;
            this.expense = expense;
            this.budget = budget;

            linePaint = new Paint();
            linePaint.setColor(Color.BLUE);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(2f);

            pointPaint = new Paint();
            pointPaint.setColor(Color.BLUE);
            pointPaint.setStyle(Paint.Style.FILL);

            path = new Path();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int width = getWidth();
            int height = getHeight();

            float xIncome = width * 0.1f;
            float xExpense = width * 0.5f;
            float xBudget = width * 0.9f;

            float yIncome = height - (income * 0.5f);
            float yExpense = height - (expense * 0.5f);
            float yBudget = height - (budget * 0.5f);

            path.reset();
            path.moveTo(xIncome, yIncome);
            path.lineTo(xExpense, yExpense);
            path.lineTo(xBudget, yBudget);

            canvas.drawPath(path, linePaint);
            canvas.drawCircle(xIncome, yIncome, 4f, pointPaint);
            canvas.drawCircle(xExpense, yExpense, 4f, pointPaint);
            canvas.drawCircle(xBudget, yBudget, 4f, pointPaint);
        }
    }
}




