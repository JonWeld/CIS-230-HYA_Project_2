package com.example.expense_trackerexperimental_20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView incomeTextView;
    private TextView expenseTextView;
    private TextView budgetTextView;

    private int income = 0;
    private int expense = 0;
    private int budget = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        incomeTextView = findViewById(R.id.incomeTextView);
        expenseTextView = findViewById(R.id.expenseTextView);
        budgetTextView = findViewById(R.id.budgetTextView);

        Button addIncomeButton = findViewById(R.id.addIncomeButton);
        Button addExpenseButton = findViewById(R.id.addExpenseButton);
        Button setBudgetButton = findViewById(R.id.setBudgetButton);
        Button generateReportButton = findViewById(R.id.generateReportButton);
        Button resetButton = findViewById(R.id.resetButton);

        addIncomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                income += 100;
                updateIncomeExpenseBudget();
            }
        });

        addExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expense += 50;
                updateIncomeExpenseBudget();
            }
        });

        setBudgetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                budget += 200;
                updateIncomeExpenseBudget();
            }
        });

        generateReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openReportActivity();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetMenu();
            }
        });
    }

    private void updateIncomeExpenseBudget() {
        incomeTextView.setText(getString(R.string.income_) + income);
        expenseTextView.setText(getString(R.string.expense_) + expense);
        budgetTextView.setText(getString(R.string.budget_) + budget);
    }

    private void openReportActivity() {
        Intent intent = new Intent(this, ReportActivity.class);
        intent.putExtra("income", income);
        intent.putExtra("expense", expense);
        intent.putExtra("budget", budget);
        startActivity(intent);
    }

    private void resetMenu() {
        income = 0;
        expense = 0;
        budget = 0;
        updateIncomeExpenseBudget();
    }
}


